package com.example.funappmanga.ui.Screens.MangaDetails

import androidx.lifecycle.ViewModel
import com.example.funappmanga.data.model.Manga
import com.example.funappmanga.data.model.MangaRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class DetailViewModel : ViewModel() {

    private val _uiState = MutableStateFlow<DetailUiState>(DetailUiState.Loading)
    val uiState: StateFlow<DetailUiState> = _uiState.asStateFlow()

    fun loadManga(mangaId: Int){

        //Buscamos el manga en nuestro repo.
        val manga = MangaRepository.getMangaById(mangaId)
        if (manga != null){
            _uiState.value = DetailUiState.Success(manga)
        }else {
            _uiState.value = DetailUiState.Error("Manga no encontrado...")
        }

    }

}

sealed class DetailUiState {
    object Loading : DetailUiState()
    data class Success(val manga: Manga): DetailUiState()
    data class Error(val message: String): DetailUiState()
}