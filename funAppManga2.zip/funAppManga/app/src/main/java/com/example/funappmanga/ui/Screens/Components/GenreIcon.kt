package com.example.funappmanga.ui.Screens.Components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.unit.dp
import com.example.funappmanga.data.model.MangaCategory

@Composable
fun GenreIcon(category: MangaCategory, modifier: Modifier = Modifier) {
    Canvas(modifier = modifier.size(20.dp)) {
        when (category) {
            // SHONEN: Un círculo rojo (energía/acción)
            MangaCategory.SHONEN -> {
                drawCircle(
                    color = Color.Red,
                    radius = size.minDimension / 2
                )
            }
            // SEINEN: Un cuadrado gris oscuro (seriedad/madurez)
            MangaCategory.SEINEN -> {
                drawRect(
                    color = Color(0xFF333333),
                    size = size
                )
            }
            // SHOJO: Un triángulo rosa (estética/romance)
            MangaCategory.SHOJO -> {
                val path = Path().apply {
                    moveTo(size.width / 2f, 0f)// Punto arriba centro
                    lineTo(size.width, size.height)// Esquina inferior derecha
                    lineTo(0f, size.height)// Esquina inferior izquierda
                    close()// Volver al inicio
                }
                drawPath(path = path, color = Color(0xFFFFC0CB))
            }
        }
    }
}