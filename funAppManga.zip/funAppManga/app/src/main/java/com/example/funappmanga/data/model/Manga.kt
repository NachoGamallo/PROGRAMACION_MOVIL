package com.example.funappmanga.data.model

enum class MangaCategory{
    SHONEN, SEINEN, SHOJO
}

data class Manga(
    val id: Int,
    val name: String,
    val desc: String,
    val category: MangaCategory,
    val imgURL : String,
    val videoURL: String = "",
    val isFavorite: Boolean = false
)

val mockMangas = listOf(
    Manga(1,"One Piece","Piratas y aventuras", MangaCategory.SHONEN, "https://wallpapers.com/images/featured/one-piece-c0pujiakubq5rwas.jpg"),
    Manga(2, "Berserk", "Fantasía oscura", MangaCategory.SEINEN, "https://static0.cbrimages.com/wordpress/wp-content/uploads/2024/02/berserk-dark.jpg?w=1200&h=675&fit=crop"),
    Manga(3, "Nana", "Drama y romance", MangaCategory.SHOJO, "https://proassetspdlcom.cdnstatics2.com/usuaris/libros/thumbs/5e2129be-7fcf-4118-8043-72f76ce5234e/d_1200_1200/portada_nana-n-0107_ai-yazawa_202501091631.webp"),
    Manga(4, "Naruto", "Ninjas", MangaCategory.SHONEN, "https://m.media-amazon.com/images/M/MV5BZTNjOWI0ZTAtOGY1OS00ZGU0LWEyOWYtMjhkYjdlYmVjMDk2XkEyXkFqcGc@._V1_FMjpg_UX1000_.jpg"),
    Manga(5,"Jujutsu Kaisen", )

)