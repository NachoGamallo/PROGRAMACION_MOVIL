package com.example.bouncingball.game

import android.content.Context
import android.graphics.Canvas
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.graphics.Color
import android.graphics.Paint

class gameView (context : Context) : SurfaceView(context), SurfaceHolder.Callback {

    private var thread: GameThread? = null
    private var ballX: Float = 100f
    private var ballY: Float = 100f
    private var ballRadius: Float = 30f
    private var speedX: Float = 15f
    private var speedY: Float = 15f

    init {
        holder.addCallback(this)
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        thread = GameThread(holder,this)
        thread?.start()
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {}

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        var retry = true
        while (retry){

            try {
                thread?.join()
                retry = false
            }catch (e: InterruptedException){//RETRY
            }
        }

    }

    fun resumeGame(){thread?.running = true}
    fun pauseGame(){thread?.running = false}
    fun update(){

        if (width == 0 || height == 0) return

        ballX += speedX
        ballY += speedY

        //Bounce the ball when it hits the screen edges
        if (ballX - ballRadius < 0 || ballX + ballRadius > width) {

            speedX = -speedX * 1.1f
            ballRadius++

        }
        if (ballY - ballRadius < 0 || ballY + ballRadius > height) {

            speedY = -speedY * 1.1f
            ballRadius++

        }

    }

    override fun draw(canvas: Canvas) {
        super.draw(canvas)
        canvas.drawColor(Color.BLACK)
        val paint = Paint()
        paint.color = Color.WHITE
        canvas.drawCircle(ballX, ballY, ballRadius, paint)
    }
}


