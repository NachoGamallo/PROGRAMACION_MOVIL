package com.example.bouncingball.game

import android.graphics.Canvas
import android.view.SurfaceHolder

class GameThread (
    private val surfaceHolder: SurfaceHolder, private val gameView: gameView
) : Thread() {

    var running = true

    override fun run() {

        while (running){

            val canvas: Canvas? = surfaceHolder.lockCanvas()
            if (canvas != null){

                gameView.update()
                gameView.draw(canvas)
                surfaceHolder.unlockCanvasAndPost(canvas)

            }

            try {
                sleep(16)
            }catch (e: InterruptedException) { e.printStackTrace() }

        }

    }

}