package com.example.bouncingball

import android.os.Bundle
import androidx.activity.ComponentActivity
import com.example.bouncingball.game.gameView

class MainActivity : ComponentActivity() {

    private lateinit var gameView: gameView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        gameView = gameView(this)
        setContentView(gameView)
    }

    override fun onResume() {
        super.onResume()
        gameView.resumeGame()
    }

    override fun onPause() {
        super.onPause()
        gameView.pauseGame()
    }

}