package com.example.funappmanga.ui.Screens.MangaDetails

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.funappmanga.ui.Screens.Components.DetailContent
import com.example.funappmanga.ui.Screens.Components.ErrorState
import com.example.funappmanga.ui.Screens.Components.LoadingState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DetailsScreen(
    mangaId: Int,
    viewModel: DetailViewModel = viewModel(),
    onBackClick: () -> Unit

) {

    val state by viewModel.uiState.collectAsState()
    val context = LocalContext.current

    //Al iniciar vamos a cargar el objeto manga.
    LaunchedEffect(mangaId) {
        viewModel.loadManga(mangaId, context)
    }

    Scaffold (//Header para ir hacia atras.
        topBar = {
            TopAppBar(
                title = { Text("Detalles del Manga")},
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Atras")
                    }
                }
            )
        }
    ){ paddingValues ->
        //Contenido de la pantalla
        Box(modifier = Modifier.padding(paddingValues)){

            when (val uiState = state){
                is DetailUiState.Success -> {
                    DetailContent(uiState.manga)//Contenedor principal.
                }
                is DetailUiState.Loading -> LoadingState()
                is DetailUiState.Error -> {
                    ErrorState(
                        message = uiState.message,
                        onBack = {onBackClick()}
                    )
                }
            }
        }
    }
}