package com.example.funappmanga.ui.Screens.MangaDetails

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import com.example.funappmanga.data.model.Manga
import com.example.funappmanga.data.model.MangaRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class DetailViewModel : ViewModel() {

    private val _uiState = MutableStateFlow<DetailUiState>(DetailUiState.Loading)
    val uiState: StateFlow<DetailUiState> = _uiState.asStateFlow()
    var player: ExoPlayer? by mutableStateOf(null)
    private set

    fun loadManga(mangaId: Int, context: Context){

        //Buscamos el manga en nuestro repo.
        val manga = MangaRepository.getMangaById(mangaId)
        if (manga != null){
            _uiState.value = DetailUiState.Success(manga)
            if (player == null) {

                setPlayer(context, manga.videoURL)

            }

        }else {
            _uiState.value = DetailUiState.Error("Manga no encontrado...")
        }

    }

    private fun setPlayer(context: Context, url: String){
        player = ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(url))
            prepare()
        }
    }

    override fun onCleared() {
        super.onCleared()
        player?.release()//Liberamos memoría.
    }

}

sealed class DetailUiState {
    object Loading : DetailUiState()
    data class Success(val manga: Manga): DetailUiState()
    data class Error(val message: String): DetailUiState()
}