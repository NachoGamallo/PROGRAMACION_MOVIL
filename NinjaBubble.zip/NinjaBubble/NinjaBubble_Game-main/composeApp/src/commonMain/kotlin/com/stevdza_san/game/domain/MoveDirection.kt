package com.stevdza_san.game.domain

enum class MoveDirection {
    Left,
    Right,
    None
}