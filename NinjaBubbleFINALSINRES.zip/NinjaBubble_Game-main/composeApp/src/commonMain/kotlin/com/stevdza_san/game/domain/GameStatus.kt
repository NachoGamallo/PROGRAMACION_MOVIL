package com.stevdza_san.game.domain

enum class GameStatus {
    Idle,
    Started,
    Over,
    Win
}