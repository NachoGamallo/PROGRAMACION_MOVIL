package com.example.jetpackcomposemedium2

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBox
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.windowsizeclass.WindowWidthSizeClass
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.vector.ImageVector

data class HabitPerQunatity(
    val name: String,
    val icon: ImageVector,
    val actualQunatity: Double,
    val objetiveQuantity: Double,
)

data class HabitPerDays(

    val name: String,
    val icon: ImageVector,
    val maxRecord: Int,
    val objetiveDays: Int,
    val actualCount: Int

)

val defaultDoubleValue : Double = 0.0
val defaultIntValue : Int = 0

val listofHabitsPerDays : List<HabitPerDays> = listOf(

    HabitPerDays("No Fumar", Icons.Default.Clear, 1,30, defaultIntValue),
    HabitPerDays("Comer comida saludable",Icons.Default.Favorite,1,3,1),
    HabitPerDays("Salir de casa",Icons.Default.Home,13,30, defaultIntValue),

    )
val listofHabitsPerQunatity : List<HabitPerQunatity> = listOf(

    HabitPerQunatity("Correr 10 KM", Icons.Default.Person, defaultDoubleValue,10.0),
    HabitPerQunatity("Leer por 10 minutos", Icons.Default.AccountBox, defaultDoubleValue,10.0)

)


@Composable
fun MainActivity3(widthSizeClass: WindowWidthSizeClass){



}


